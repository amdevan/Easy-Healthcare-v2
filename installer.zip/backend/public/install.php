<?php
/**
 * Easy Healthcare 101 - Auto Installer & Diagnostics Tool
 * Place this file in your 'public' folder (e.g., public_html or backend/public)
 */

// Basic Security
if (file_exists(__DIR__ . '/../storage/installed')) {
    die("Application is already installed. Delete 'storage/installed' to re-run this script.");
}

$action = $_GET['action'] ?? 'home';
$message = '';
$error = '';

function getBaseDir() {
    return dirname(__DIR__);
}

function checkPermission($path) {
    return is_writable($path);
}

function fixPermission($path) {
    try {
        chmod($path, 0755);
        return is_writable($path);
    } catch (Exception $e) {
        return false;
    }
}

// Handle Actions
if ($action == 'fix_permissions') {
    $dirs = [
        getBaseDir() . '/storage',
        getBaseDir() . '/storage/app',
        getBaseDir() . '/storage/app/public',
        getBaseDir() . '/storage/framework',
        getBaseDir() . '/storage/framework/views',
        getBaseDir() . '/storage/framework/cache',
        getBaseDir() . '/storage/framework/sessions',
        getBaseDir() . '/storage/logs',
        getBaseDir() . '/bootstrap/cache',
    ];

    $count = 0;
    foreach ($dirs as $dir) {
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
        if (fixPermission($dir)) {
            $count++;
        }
    }
    $message = "Attempted to fix permissions. Checked/Fixed $count directories.";
}

if ($action == 'symlink') {
    $target = getBaseDir() . '/storage/app/public';
    $link = __DIR__ . '/storage';
    
    if (file_exists($link) && !is_link($link)) {
        $error = "A folder named 'storage' already exists. <a href='?action=force_symlink' style='color: white; text-decoration: underline;'>Click here to fix it automatically</a>.";
    } elseif (file_exists($link)) {
        $message = "Link already exists.";
    } else {
        if (symlink($target, $link)) {
            $message = "Storage symlink created successfully.";
        } else {
            $error = "Failed to create symlink. Try running 'php artisan storage:link' via SSH.";
        }
    }
}

if ($action == 'force_symlink') {
    $target = getBaseDir() . '/storage/app/public';
    $link = __DIR__ . '/storage';
    
    if (file_exists($link) && !is_link($link)) {
        rename($link, $link . '_backup_' . time());
    }
    
    if (symlink($target, $link)) {
        $message = "Fixed! Old folder renamed to storage_backup and link created.";
    } else {
        $error = "Failed to create link.";
    }
}

if ($action == 'generate_key') {
    // We need to load Laravel for this, or do it manually
    // Manual generation for safety on shared hosting without shell
    $key = 'base64:' . base64_encode(random_bytes(32));
    $envPath = getBaseDir() . '/.env';
    
    if (file_exists($envPath)) {
        $content = file_get_contents($envPath);
        $content = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY=' . $key, $content);
        file_put_contents($envPath, $content);
        $message = "Generated new APP_KEY: $key";
    } else {
        $error = ".env file not found.";
    }
}

if ($action == 'copy_env') {
    $example = getBaseDir() . '/.env.example';
    $target = getBaseDir() . '/.env';
    
    if (!file_exists($target) && file_exists($example)) {
        copy($example, $target);
        $message = ".env file created from .env.example";
    } elseif (file_exists($target)) {
        $error = ".env already exists.";
    } else {
        $error = ".env.example missing.";
    }
}

// Check Status
$phpVersion = phpversion();
$phpOk = version_compare($phpVersion, '8.1.0', '>=');

$extensions = ['bcmath', 'ctype', 'fileinfo', 'json', 'mbstring', 'openssl', 'pdo', 'tokenizer', 'xml'];
$extStatus = [];
foreach ($extensions as $ext) {
    $extStatus[$ext] = extension_loaded($ext);
}

$permDirs = [
    'storage' => getBaseDir() . '/storage',
    'bootstrap/cache' => getBaseDir() . '/bootstrap/cache',
];

$envExists = file_exists(getBaseDir() . '/.env');
$symlinkPath = __DIR__ . '/storage';
$symlinkExists = file_exists($symlinkPath) && is_link($symlinkPath);
$symlinkBlocked = file_exists($symlinkPath) && !is_link($symlinkPath);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Easy Healthcare Installer</title>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; background: #f0f2f5; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }
        h1 { margin-top: 0; color: #1a1a1a; }
        h2 { font-size: 1.2rem; color: #4a5568; border-bottom: 2px solid #edf2f7; padding-bottom: 10px; }
        .status { padding: 4px 8px; border-radius: 4px; font-size: 0.9rem; font-weight: bold; }
        .ok { background: #c6f6d5; color: #22543d; }
        .bad { background: #fed7d7; color: #822727; }
        .warn { background: #fefcbf; color: #744210; }
        .btn { display: inline-block; background: #3182ce; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-top: 10px; }
        .btn:hover { background: #2c5282; }
        .alert { padding: 15px; border-radius: 4px; margin-bottom: 20px; }
        .alert-success { background: #c6f6d5; color: #22543d; }
        .alert-error { background: #fed7d7; color: #822727; }
        code { background: #edf2f7; padding: 2px 5px; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="card">
        <h1>🏥 Easy Healthcare Installer</h1>
        <p>Use this tool to fix common server configuration issues automatically.</p>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </div>

    <!-- 1. Environment -->
    <div class="card">
        <h2>1. Server Requirements</h2>
        <p>PHP Version: <strong><?php echo $phpVersion; ?></strong> 
            <span class="status <?php echo $phpOk ? 'ok' : 'bad'; ?>">
                <?php echo $phpOk ? 'OK' : 'Requires 8.1+'; ?>
            </span>
        </p>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
            <?php foreach ($extStatus as $ext => $loaded): ?>
                <div>
                    <?php echo $ext; ?>: 
                    <span class="status <?php echo $loaded ? 'ok' : 'bad'; ?>">
                        <?php echo $loaded ? 'OK' : 'MISSING'; ?>
                    </span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- 2. .env File -->
    <div class="card">
        <h2>2. Configuration File (.env)</h2>
        <p>Status: 
            <span class="status <?php echo $envExists ? 'ok' : 'bad'; ?>">
                <?php echo $envExists ? 'Found' : 'Missing'; ?>
            </span>
        </p>
        <?php if (!$envExists): ?>
            <p>The .env file contains your database settings.</p>
            <a href="?action=copy_env" class="btn">Create .env from Example</a>
        <?php else: ?>
            <p>✅ .env exists. Make sure you edited it with your Database details!</p>
            <a href="?action=generate_key" class="btn">Generate New App Key</a>
        <?php endif; ?>
    </div>

    <!-- 3. Permissions -->
    <div class="card">
        <h2>3. Folder Permissions</h2>
        <?php foreach ($permDirs as $name => $path): ?>
            <p>
                <?php echo $name; ?>: 
                <span class="status <?php echo is_writable($path) ? 'ok' : 'bad'; ?>">
                    <?php echo is_writable($path) ? 'Writable (OK)' : 'Not Writable'; ?>
                </span>
            </p>
        <?php endforeach; ?>
        
        <?php if (!is_writable($permDirs['storage']) || !is_writable($permDirs['bootstrap/cache'])): ?>
            <a href="?action=fix_permissions" class="btn">Attempt to Fix Permissions</a>
        <?php endif; ?>
    </div>

    <!-- 4. Storage Link -->
    <div class="card">
        <h2>4. Storage Link</h2>
        <p>Images require a "symlink" from <code>public/storage</code> to <code>storage/app/public</code>.</p>
        <p>Status: 
            <?php if ($symlinkExists): ?>
                <span class="status ok">Linked (OK)</span>
            <?php elseif ($symlinkBlocked): ?>
                <span class="status bad">BLOCKED (Folder Exists)</span>
            <?php else: ?>
                <span class="status bad">Missing</span>
            <?php endif; ?>
        </p>
        
        <?php if ($symlinkBlocked): ?>
            <p style="color:red; font-weight:bold;">⚠️ Error: A real folder named "storage" exists in "public".</p>
            <a href="?action=force_symlink" class="btn" style="background: #e53e3e;">Fix Automatically (Rename & Link)</a>
        <?php elseif (!$symlinkExists): ?>
            <a href="?action=symlink" class="btn">Create Storage Symlink</a>
        <?php endif; ?>
    </div>

    <!-- 5. Final Check -->
    <div class="card">
        <h2>5. Final Steps</h2>
        <p>If all checks above are Green:</p>
        <ol>
            <li>Edit <code>.env</code> and set your Database details.</li>
            <li>Visit your Admin Panel: <a href="index.php">Go to Admin</a></li>
        </ol>
        <p><em>Note: If you see a 500 Error, check the Permissions section again.</em></p>
    </div>
</body>
</html>
